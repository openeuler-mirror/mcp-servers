#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
"""
Tool execution total entrance
"""
import asyncio
from cli.base import CveTrackingCommand
from conf import CONFIG
from exception import CveException
from logger import logger

try:
    # Register all subcommands
    for sub_class in CveTrackingCommand.__subclasses__():
        CveTrackingCommand.register_command(sub_class())

    # Parallel execution of corresponding functions
    loop = asyncio.get_event_loop()
    loop.run_until_complete(CveTrackingCommand.run())
except CveException as errors:
    logger.error(
        f'Execution failed, message is : {errors.message}, detail in {CONFIG.LOGGER_PATH}/{CONFIG.LOGGER_FILE_NAME}')
