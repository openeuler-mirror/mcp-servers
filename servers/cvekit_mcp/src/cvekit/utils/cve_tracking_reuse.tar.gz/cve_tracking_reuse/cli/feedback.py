#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
from cli import CveTrackingCommand
from conf import CONFIG
from constant import Constant
from core.feedback.issue_mode import IssueMode
from exception import InputError
from logger import logger


class FeedbackCommand(CveTrackingCommand):
    """
    Cve tool feedback function command line
    """

    def __init__(self):
        super(FeedbackCommand, self).__init__()
        self.parser = CveTrackingCommand.sub_parse.add_parser(
            name="feedback",
            help="Submit an issue to the designated warehouse, and the feedback tool will find the result",
        )
        self._add_params()

    def _add_params(self):
        """
        Add input parameters required for feedback function
        :return: None
        """
        self.parser.add_argument(
            "-c",
            "--cve_num",
            metavar="cve",
            type=str,
            required=True,
            action="store",
            default=None,
            help="cve number",
        )
        self.parser.add_argument(
            "-p",
            "--cve_platform",
            type=str,
            metavar="cve_platform",
            required=True,
            action="store",
            default=None,
            help="Correct cve reference URL",
        )
        self.parser.add_argument(
            "-u",
            "--patch_url",
            type=str,
            metavar="patch_url",
            required=True,
            action="store",
            default=None,
            help="Correct patch url",
        )
        self.parser.add_argument(
            "-i",
            "--issue_platform",
            type=str,
            metavar="issue_platform",
            required=False,
            action="store",
            choices=Constant.CODE_PLATFORM,
            default=CONFIG.FEEDBACK_PLATFORM,
            help="Issue submission platform, default is gitee",
        )

    @staticmethod
    async def run_command(args):
        """
        Feedback function execution entrance
        :param args: input params
        :return: None
        """
        logger.info(
            f"Start add issue about cve:{args.cve_num} on platform:{args.issue_platform}"
        )
        if not all(
            [args.cve_num, args.cve_platform, args.patch_url, args.issue_platform]
        ):
            raise InputError(
                msg="Feedback command params, please check and try again.")

        issue_mode = IssueMode(
            cve_num=args.cve_num,
            cve_platform=args.cve_platform,
            patch_url=args.patch_url,
            issue_platform=args.issue_platform,
        )
        result = await issue_mode.create_feedback_issue()

        if result:
            logger.info(
                f"Success to add issue about cve:{args.cve_num} on platform:{args.issue_platform}"
            )
        else:
            logger.error(
                f"Failed to add issue about cve:{args.cve_num} on platform:{args.issue_platform}, "
                f"content is cve_platform:{args.cve_platform}, patch_url:{args.patch_url}"
            )
