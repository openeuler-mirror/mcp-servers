#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
from cli.base import CveTrackingCommand
from conf import CONFIG
from core.comment.issue_comment import issue_comment
from core.crawler.patch import Patch
from core.download import save
from exception import InputError
from logger import logger
from util.atomgit_api import Atomgit


class FindAdaptivePatch(CveTrackingCommand):
    """
    Execute the command line to find the patch and save the patch file
    """

    def __init__(self):
        super(FindAdaptivePatch, self).__init__()
        self.parser = CveTrackingCommand.sub_parse.add_parser('find_adaptive_patch',
                                                              help="Search for patches, download patch files, verify and comment on patches")
        self._add_common_param()
        self._add_params()

    def _add_params(self):
        """
        Add the unique parameters of the command
        :return: None
        """
        self.parser.add_argument('-f', '--patch_path', metavar='patch_patch', type=str, action='store', required=False,
                                 default=CONFIG.PATCH_SAVE_PATH,
                                 help='Path to save the patch file, the default is"/opt/cve_tracking/patches"')
        self.parser.add_argument('-s', '--source_path', metavar='source_patch', type=str, action='store',
                                 required=False, default=CONFIG.SOURCE_CODE_PATH,
                                 help='Source download path, the default is: "/opt/cve_tracking/source_code"')
        self.parser.add_argument('-p', '--packing', action='store_true', required=False, default=False,
                                 help='Whether to package the verification patch')
        self.parser.add_argument('-b', '--branch', metavar='branch', type=str, action='store', required=False,
                                 default='master', help='Branch of rpm, default is "master"')
        self.parser.add_argument(
            "-i",
            "--issue",
            metavar="issue",
            type=str,
            required=True,
            action="store",
            default=None,
            help="CVE related issue number",
        )

    @staticmethod
    async def run_command(args):
        """
        Search patch, save file function execution entry
        :param args: command line params
        :return: None
        """
        logger.info(f'Start to execute the download command, cve: {args.cve_num}, '
                    f'rpm: {args.rpm_name}, patch save path: {args.patch_path}')
        if not all([args.rpm_name, args.cve_num, args.patch_path, args.packing]):
            raise InputError(
                'find_adaptive_patch command parameter error, please confirm "rpm_name"/cve_num/patch_path/-p"')
        if args.packing and not all([args.source_path, args.branch]):
            raise InputError(
                'find_adaptive_patch command parameter error, please confirm "source_path/branch"')
        # find patch info
        patch = Patch(cve_num=args.cve_num, rpm_name=args.rpm_name)
        patch_detail_info = await patch.find_patches_detail()

        # download patch file
        patch_url_state = save.save_patch(
            patch_details=patch_detail_info, path=args.patch_path, args=args)
        for patch in patch_detail_info:
            for issue_info in patch.get("details", list()):
                _issue_info(issue_info, patch_url_state)

        # comment cve issue
        atomgit = Atomgit()
        atomgit.set_attr(owner=CONFIG.DEFAULT_OWNER, repo=args.rpm_name)
        await issue_comment(patch_details=patch_detail_info, number=args.issue, atomgit=atomgit, packing=False)
        logger.info(
            "End to perform search and comment and download and packing functions")


def _issue_info(issue_info, patch_url_state):
    """
    For prs to get url
    :param issue_info: issue_info in patch_detail_info list
    :param patch_url_state: To pass to the next level of functions
    :return: None
    """
    for prs in issue_info["issue"].get("prs", list()):
        for url in prs.get("commits", []):
            _patch_url_state(prs, url, patch_url_state)


def _patch_url_state(prs, url, patch_url_state):
    """
    For prs to get url
    :param prs: prs in issue_info
    :param url: use url to if
    :param patch_url_state: get patch_url_state key to assignment prs["application"]
    :retur None
    """
    for key, value in patch_url_state.items():
        if key == url:
            if not prs.get("application"):
                prs["application"] = patch_url_state[key]
            else:
                prs["application"] = prs["application"] + \
                    "<br/>" + patch_url_state[key]
