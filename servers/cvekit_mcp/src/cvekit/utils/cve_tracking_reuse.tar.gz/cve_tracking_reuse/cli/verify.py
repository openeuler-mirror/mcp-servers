#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
from cli.base import CveTrackingCommand
from conf import CONFIG
from core.verification.apply import PathApply
from logger import logger


class VerifyCommand(CveTrackingCommand):
    """
    Patch verification function command line
    """

    def __init__(self):
        super(VerifyCommand, self).__init__()
        self.parser = CveTrackingCommand.sub_parse.add_parser(
            'packing', help='Test patch file application results')
        self._add_params()
        self._add_common_param()

    def _add_params(self):
        """
        Add the unique parameters of the command
        :return: None
        """
        self.parser.add_argument('-f', '--patch_path', metavar='patch_path', type=str, action='store', required=True,
                                 default=None, help='Path of patch file')
        self.parser.add_argument('-s', '--source_path', metavar='source_path', type=str, action='store', required=False,
                                 default=CONFIG.SOURCE_CODE_PATH,
                                 help='Source download path, the default is: "/opt/cve_tracking/source_code"')
        self.parser.add_argument('-b', '--branch', metavar='branch', type=str, action='store', required=False,
                                 default='master', help='Branch of rpm, default is "master"')
        self.parser.add_argument('-nd', '--no_download', action='store_true', required=False, default=False,
                                 help='Do you need to download the source code? if you choose False, '
                                      '"source path" must be specified to the local source code repository')

    @staticmethod
    async def run_command(args):
        """
        Patch test application execution entry
        :param args: command line params
        :return: None
        """
        branch = "no" if args.no_download else args.branch
        patch_apply = PathApply(rpm_name=args.rpm_name, branch_rpm=branch, patch_path=args.patch_path,
                                source_path=args.source_path, cve_num=args.cve_num)
        status = patch_apply.packing_source()
        # patch_apply.clear_trash()
        logger.info("End of adaptation Process,resule is %s" % status)
