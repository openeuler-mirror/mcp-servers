#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
import argparse


class CveTrackingCommand:
    """
    Cve tool command line related classes
    """
    arg_parse = argparse.ArgumentParser(description="Cve_tracking Tool")
    sub_parse = arg_parse.add_subparsers(description="sub-command ")

    def __init__(self):
        self.parser = None

    def _add_common_param(self):
        """
        Add public parameters and set execution method to subcommands
        :return: None
        """
        self.parser.add_argument('-c', '--cve_num', metavar='cve', type=str, required=True, action='store',
                                 default=None, help='cve number')
        self.parser.add_argument('-r', '--rpm_name', metavar='rpm', type=str, required=True, action='store',
                                 default=None, help='rpm name')

    @staticmethod
    def register_command(sub_instance):
        """
        Initialize each sub-command class and set the execution method
        :param sub_instance: sub class instance
        :return: None
        """
        sub_instance.parser.set_defaults(func=sub_instance.run_command)

    @classmethod
    async def run(cls):
        """
        Command line execution entry
        :return: None
        """
        args = cls.arg_parse.parse_args()
        await args.func(args)
