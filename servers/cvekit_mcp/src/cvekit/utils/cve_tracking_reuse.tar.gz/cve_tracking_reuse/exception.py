#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
class CveException(BaseException):
    """
    The parent exception class of the cve tracking tool
    """

    def __init__(self, msg):
        super(CveException, self).__init__()
        self.message = msg

    def __repr__(self):
        return self.message


class ConfigNotFoundError(CveException):
    """
    Configuration file not found exception
    """

    def __init__(self, msg):
        super(ConfigNotFoundError, self).__init__(f'Configuration file not found: {msg}')


class InputError(CveException):
    """
    Input params error
    """

    def __init__(self, msg):
        super(InputError, self).__init__(f'Input parameter error: {msg}')


class RequestError(CveException):
    """
    Error calling URL
    """

    def __init__(self, msg):
        super(RequestError, self).__init__(f'Error calling URL: {msg}')


class PathNotExistError(CveException):
    """
    Path not exist error
    """

    def __init__(self, msg):
        super(PathNotExistError, self).__init__(f'Path not exist: {msg}')


class PathEmptyError(CveException):
    """
    Path is empty error
    """

    def __init__(self, msg):
        super(PathEmptyError, self).__init__(f'Path is empty: {msg}')
