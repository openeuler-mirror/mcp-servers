# cve_tracking

#### 介绍

cve 补丁自动获取工具，该工具将会根据 cve 和 rpm 包自动在上游社区查找补丁并反馈结果，同时也可以下载查找到的补丁以及验证补丁的可用性。

#### 软件架构

python 可执行代码

#### 安装教程

1. 下载代码

   ```shell
   git clone https://gitee.com/openeuler/cve-manager.git
   ```

2. 进入工具执行目录

   ```shell
   cd xxx(上述代码下载目录)/cve-manager/cve-agency-manager/cve_tracking
   ```

3. 在 cve-tracking.yaml 的 authentication 中设置 gitee（gitee 的私人令牌）和 gitlab（gitlab 的私人令牌，默认设置了一个临时令牌，可临时使用），github（github 的私人令牌）可不设置。

4. 安装依赖包

   ```
   pip3 install -r requirements.txt
   ```

5. 根据使用说明执行工具

#### 使用说明

1. 补丁查找及评论 issue

   ```shell
   python3 main.py comment -c cve_num -r rpm_name -i issue_num
   ```

   > 参数说明：
   >
   > -c cve 的编号
   >
   > -r rpm 包名称
   >
   > -i 需要评论的 issue 编号
   >
   > 注意：请修改 main.py 同目录下 cve-tracking.yaml 中的  # 访问api的私人令牌 token 的值与 config.ini 中的 DEFAULT_OWNER 的值

2. 补丁查找及下载(验证)

   ```shell
   python3 main.py download -c cve_num -r rpm_name [-f patch_save_path] [-s source_path] [-p] [-b branch]
   ```

   > 参数说明：
   >
   > -c cve 的编号
   >
   > -r rpm 包名称
   >
   > -f 补丁文件的下载目录，不设置默认为/opt/cve_tracking/patches
   >
   > -s 源码包下载路径，不设置默认为/opt/cve_tracking/source_code
   >
   > -b 源码包所在的 gitee 的 src-openeuler 仓库的分支，默认为 master
   >
   > -p 是否进行补丁应用，默认为不应用，若需要应用，添加该参数。

3. 补丁验证

   ```shell
   python3 main.py packing -r rpm_name -c cve_num -f patch_save_path -s source_path -b branch [-nd]
   ```

   > 参数说明：
   >
   > -r rpm 包名称
   >
   > -c cve 的编号
   >
   > -f 补丁文件路径（指定到补丁所在的文件夹即可）
   >
   > -s 源码包路径，如果无需下载指定为本地源码包的路径；如果需要下载指定为需要下载源码包的路径即可
   >
   > -b 源码包所在 gitee 中 src-openeuler 仓库的分支，不设置默认为 master
   >
   > -nd 是否需要下载源代码，默认为需要下载，若无需下载添加该参数

4. 查找下载验证及评论
   
   ```shell
   python3 main.py find_adaptive_patch -c cve_num -r rpm_name [-f patch_save_path] [-s source_path] -p [-b branch] [-nd] -i issue_num
   ```

   
   > 参数说明：
   >
   > -c cve 的编号
   >
   > -r rpm 包名称
   >
   > -f 补丁文件的下载目录，不设置默认为/opt/cve_tracking/patches
   >
   > -s 源码包下载路径，不设置默认为/opt/cve_tracking/source_code
   >
   > -b 源码包所在的 gitee 的 src-openeuler 仓库的分支，默认为 master
   >
   > -nd 是否需要下载源代码，默认为需要下载，若无需下载添加该参数
   >
   > -p 是否进行补丁应用，默认为不应用，若需要应用，添加该参数。
   >
   > -i 需要评论的 issue 编号
   >
   > 注意：请修改 main.py 同目录下 cve-tracking.yaml 中的  # 访问api的私人令牌 token 的值与 config.ini 中的 DEFAULT_OWNER FEEDBACK_ISSUE_OWNER FEEDBACK_ISSUE_REPO 的值

5. 意见反馈

   若工具没有查找到补丁且人工查找到补丁信息，可通过该功能进行反馈，将会在配置的平台中提交 issue。将发现新 patch 的平台信息上报至指定的仓库，便于 CVE 修复人员完善工具的查找。指定的仓库可以在 conf.ini 配置文件的【FEEDBACK】中进行配置

   ```shell
   python3 main.py feedback -c cve_num -p cve_platform -u patch_url -i issue_warehouse
   ```

   > 参数说明：
   >
   > -c CVE 的编号
   >
   > -p 查找 CVE 所在的平台，可按照平台名称简写
   >
   > -u 修复 CVE 的补丁链接
   >
   > -i 管理 issue 的仓库，只能是（gitee、gitlab、github）中任选其一

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request

#### 特技

1.  使用 Readme_XXX.md 来支持不同的语言，例如 Readme_en.md, Readme_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
