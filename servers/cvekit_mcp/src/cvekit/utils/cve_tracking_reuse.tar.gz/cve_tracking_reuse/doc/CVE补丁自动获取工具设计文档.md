# CVE 补丁自动获取工具设计文档

## 一、需求概述

### 1.1、需求描述

开源社区中大部分软件都是第三方开源软件，这无法避免会存在漏洞，快速发现并及时修复 cve 漏洞是衡量一个开源社区是否健康的重要 指标之一。cve_tracking 工具旨在自动查找 cve 的修复补丁，减少人工查找时间，提高 cve 修复速度，保障社区健康运行。

### 1.2、受益人

| 角色         | 角色描述                                                                                                            |
| ------------ | ------------------------------------------------------------------------------------------------------------------- |
| 版本经理     | 负责版本发布、维护和进度看护的人员，版本发布要求解决高分 CVE，cve_tracking 可以帮助快速解决 CVE，保证版本发布进度。 |
| 社区维护人员 | 负责修复 CVE 的人员，可以使用 cve_tracking，减少查找工作量，提高解决速度。                                          |
| 社区开发人员 | 自研软件包的开发人员，可以使用补丁验证模块功能进行补丁验证。                                                        |

### 1.3、依赖组件

| 组件                           | 组件描述                                       | 可获得性         |
| ------------------------------ | ---------------------------------------------- | ---------------- |
| python3                        | Python 程序运行环境，需要 python3.6 以上版本。 | openEuler 已集成 |
| python3-retrying               | requests 请求重试依赖程序库                    | openEuler 已集成 |
| python3-concurrent-log-handler | python 日志程序库，包括日志记录，日志转储      | openEuler 已集成 |
| python3-pyyaml                 | python 处理 yaml 文件程序库                    | openEuler 已集成 |
| python3-asyncio                | python 异步执行 io 操作程序库                  | openEuler 已集成 |
| python3-bs4                    | python 处理 html 格式程序库                    | openEuler 已集成 |
| python3-aiohttp                | python 异步请求 web 资源操作程序库             | openEuler 已集成 |
| python3-wget                   | python 下载 web 资源程序库                     | openEuler 已集成 |
| python3-fake_useragent         | python 请求 api 设置代理程序库                 | openEuler 已集成 |
| python3-lxml                   | python 解析 xml 程序库                         | openEuler 已集成 |

### 1.4、特性需求

| 需求编号 | 需求描述   | 特性描述                                                                     |
| -------- | ---------- | ---------------------------------------------------------------------------- |
| 1        | 补丁查找   | 通过 cve 参考网址和查找规则进行补丁链接匹配查找。                            |
| 2        | issue 评论 | 将查找到的补丁链接添加到相关 issue 的评论中。                                |
| 3        | 补丁下载   | 通过查找到的补丁链接，将补丁文件下载保存。                                   |
| 4        | 补丁验证   | 下载补丁文件后，进行补丁打包验证。                                           |
| 5        | 补丁反馈   | 若工具为找到补丁，通过命令向指定仓库提交 issue，方便数据统计和后续工具优化。 |

## 二、设计概述

### 2.1、 设计原则

- 数据与代码分离： 功能实现是需要考虑哪些数据是需要配置动态改变的，不可在代码中将数据写死，应提取出来做成可配置项。
- 接口与实现分离：外部依赖模块接口而不是依赖模块实现。
- 模块划分： 不同功能划分不同模块，使用命令行参数进行灵活组合，模块之间保证无循环调用。
- 并行处理：采用多线程，协程等技术，并行请求外部 api，减少 IO 等待时间，提高处理速度。
- 变更： 架构设计变更、外部接口变更、特性需求变更需要结合开发、测试等所有相关人员经过开会讨论后决策，不可擅自变更。

## 三、需求分析

### 3.1、使用场景

- 在线使用：和 cve_manager 集成，提交 cve 的 issue 时自动触发，也可以通过/find-patch 命令进行触发，该方式只输出参考网址，相关 pr 和补丁链接，无下载和验证信息。

> 评论格式
>
> | 参考网址                                                  | 关联 pr                                        | 状态  | 补丁链接                                                                                                                                                                                       |
> | --------------------------------------------------------- | ---------------------------------------------- | ----- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | https://bugzilla.redhat.com/show_bug.cgi?id=CVE-2020-1735 | https://github.com/ansible/ansible/pull/68780/ | close | https://github.com/ansible/ansible/pull/68780/commits/5292482553dc409081f7f4368398358cbf9f8672，https://github.com/ansible/ansible/pull/68780/commits/5292482553dc409081f7f4368398358cbf9f8673 |
> | https://ubuntu.com/security/CVE-2019-10156                |                                                |       | https://github.com/ansible/ansible/pull/57188/commits/8254c266f962d5febe46396d5083bb9c1da74840，https://github.com/ansible/ansible/pull/57188/commits/fbda0028750a17a032d83dad9d1fb284f9ea68a4 |

​ 反馈功能：如果工具未找到补丁信息，但是人工可以找到，可以通过在评论中添加一下内容进行反馈：

```shell
/feedback  "cve参考网址"  "补丁url"
```

​ 该操作将在https://gitee.com/liheavy/cve_tracking仓库中提交相关issue。可通过config.ini中的"FEEDBACK"中的配置来更改提交issue所在的仓库。

- 本地使用：下载工具后，通过 python 调用，该方式支持下载补丁和验证补丁的操作，也支持补丁反馈功能，具体操作见 readme 指导文档。

### 3.2、用例视图

![](images\用例图.png)

> 说明：
>
> - 社区维护人员是该工具的主要使用者，用于快速查找补丁，及时修复 cve，当工具未找到相关补丁时可使用反馈功能进行反馈。
> - 社区开发人员可以使用补丁验证模块，快速打包验证，可根据反馈信息不断提升工具的查找率和正确率。
> - 版本经理主要是利用该工具，能更好保障版本的顺利发布。

### 3.3、逻辑视图

![](images\逻辑视图.png)

### 3.4、代码结构

![](images\代码模块.png)

### 3.5、时序视图

![](images\时序图.png)

### 3.6、开发视图

![](images/开发视图.png)

### 3.7、质量设计

##### 3.7.1、性能规格

| 规格项 | 功能点                 | 规格指标                                                                                              |
| ------ | ---------------------- | ----------------------------------------------------------------------------------------------------- |
| 效率   | 补丁下载               | 由于补丁平台的网络访问可能存在不稳定性以及补丁大小区别，将重试三次，每次重试 2min，总时间限制为 10min |
| 效率   | 提交评论 <br/>工具反馈 | 由于补丁平台的网络访问可能存在不稳定性，将重试三次，每次重试时间为 1min，总时间限制为 3min            |
| 效率   | 补丁验证               | 由软件包编译流程和编译环境决定，无时间限制。                                                          |

**补丁查找性能提升策略：**

![](images\性能策略.png)

##### 3.7.2、可靠性设计

| 影响因素   | 使用场景   | 可靠性说明                                                                                                                      |
| ---------- | :--------- | ------------------------------------------------------------------------------------------------------------------------------- |
| 高并发     | 在线、本地 | 基于当前主要使用场景为在线使用，每次执行只输入单个 cve，所以多个请求也只会顺序执行，资源控制由操作系统调度。                    |
| 进程异常   | 在线、本地 | 当前工具为 python 调用方式，当系统故障或者进程异常退出，执行中断，后续执行不会受影响。                                          |
| 结果正确性 | 在线、本地 | 工具采用多个 cve 参考平台共同查找的方式，平台信息各自展示，可通过交叉对比提升结果准确性。同时提供反馈功能，不断提升工具准确性。 |

##### 3.7.3、安全性设计

| 功能点           | 涉及安全项       | 解决策略                                                                                    |
| ---------------- | ---------------- | ------------------------------------------------------------------------------------------- |
| 上游社区信息获取 | 上游社区 token   | 不需要登录的将直接访问，必须登录的将支持用户在配置文件配置临时 token。                      |
| issue 评论       | gitee 私人令牌   | 主要使用场景为和 cve_manager 集成，将使用机器人令牌。本地执行支持用户配置临时全局环境变量。 |
| 补丁验证         | 软件包安装，编译 | 必须使用 root 权限的操作，需用户保证拥有对应权限，不涉及用户名密码保存。                    |
| 补丁反馈         | 提交 issue       | 无需用户名密码，需要 token，token 可设置环境变量和写入配置文件，由用户自己保存。            |

### 3.8、扩展性设计

#### 3.8.1、查找平台扩展

工具采用 yaml 配置查找平台及对应的查找规则，支持动态扩展，开发者只要按照定义的 yaml 配置文件（cve-tracking.yaml）规则和说明配置对应平台信息即可，当 yaml 配置项不满足时可调整 yaml 解析类进行扩展。

```yaml
# 匹配cve补丁信息的正则表达式
regex:
  # 匹配内容的类型的标签，当前只支持 "commit"/"pr"/"issue"
  - label: commit
    # 匹配特定类型内容的正则表达式，可以设置多个匹配规则
    regular:
      - http[s]?://(?:[-\w.\/;?])+(?:/rev|/ci|/commit[s]?)/(?:\?id=)?[0-9a-z]{8,40}
      - http[s]?://(?:[-\w.\/;=&?])+a=commit(?:[\w;&?])+h=[0-9a-z]{8,40}
  - label: pr
    regular:
      - http[s]?://(?:[-\w.\/;?])+(?:pull[s]?|merge_requests)/[1-9][0-9]*
  - label: issue
    regular:
      - http[s]?://(?:[-\w.\/;?])+issues/[0-9A-Z]+

# 查找cve漏洞修复的平台，例如 Debian、Bugzilla、Nvd等
platform:
  # The name of the platform, similar to a label
  # 平台的名称(必配项)
  - name: Cnnvd
    # Request address to find CVE information,{cve_num} is a placeholder for string substitution in Python
    # 查找cve详情信息的请求地址，“{cve_num}”是python中字符串替换的占位符(必配项)
    url: http://cnnvd.org.cn/web/vulnerability/queryLds.tag?qcvCnnvdid={cve_num}
    # 发送请求的方式，默认为get请求，还可以指定为post请求，当请求方式为get时，此处可不配置
    method: get
    # 若请求方式为post且存在请求体时，body为必填项，且必须为json格式，当请求方式为get时，此处可不配置
    body:
    # 解析响应体的方式，当前只支持“text”或“json”(必配项)
    format: text
    # 当请求无法直接获取cve信息时（根据页面中特定链接多次跳转），可以指定页面跳转的方式来获取进一步的信息
    redirect:
      # 跳转地址的前缀，一般情况下为跳转页面的域名，如果正则表达式匹配到的跳转地址中有完整的域名+路径，此配置项可以不填写
      - prefix: http://cnnvd.org.cn
        # 匹配页面跳转地址的正则表达式，如果匹配多个值，则获取最后一个匹配项
        regex: /web/xxk/ldxqById\.tag\?CNNVD=CNNVD[0-9-]+
        # 送请求的方法，默认为get请求，还可以指定为post请求，当请求为get时，此处可不配置
        method: get
        # 若请求方式为post且存在请求体时，body为必填项，且必须为json格式
        body:

  - name: Debian
    url: https://security-tracker.debian.org/tracker/{cve_num}
    format: text

  - name: Ubuntn
    url: https://ubuntu.com/security/{cve_num}
    format: text

  - name: Bugzilla
    url: https://bugzilla.redhat.com/rest/bug/{cve_num}/comment
    format: json

  - name: Nvd
    url: https://nvd.nist.gov/vuln/detail/{cve_num}
    format: text

  - name: Suse
    url: https://bugzilla.suse.com/show_bug.cgi?id={cve_num}
    format: text

# Private token for API access
# api访问时的私人令牌，当前只支持"gitee"/"github"/"gitlab"
authentication:
  # api名称，此值不可更改
  - name: gitee
    # 访问api的私人令牌，可以手动获取后更改
    token: xxxxxx
  - name: github
    token: xxxxxx
  - name: gitlab
    token: xxxxxxx

# 补丁包下载配置项
download:
  # 补丁包下载路径的调整，分为（REPLACE、APPEND）两种方式，分别对应了补丁路径的替换和拼接
  - action: REPLACE
    # 匹配url的正则表达式，符合特定规则的url进行特定值的替换（必填项）
    regex: http[s]?://(?:[-\w.\/;=&?])+a=commit(?:[\w;&?])+h=[0-9a-z]{8,40}
    # 替换的规则，第一个值为需要替换的内容，第二个值为替换的目标内容，如果不传递默认为（commit,patch）进行替换操作（可选配置项）
    target:
      - commit
      - patch
  - action: REPLACE
    regex: http[s]?://(?:[-\w.\/;?])+/commit[s]?/\?id=[0-9a-z]{8,40}
    target:
      - commit
      - patch
  - action: APPEND
    # 匹配url的正则表达式，符合特定规则的url进行特定值的拼接（必填项）
    regex: http[s]?://(?:[-\w.\/;?])+/commit[s]?/[0-9a-z]{8,40}
    # 拼接的规则，在url地址的末尾需要拼接的内容，如果不传递默认拼接“.patch”(可选配置项)
    target:
      - .patch
```

#### 3.8.2、功能扩展

工具采用工厂模式设计模式，当命令行和功能模块扩展时，只需增量添加对应的类即可。

![](images\扩展设计.png)

### 3.9、特性清单

**AR：补丁查找**

|           SR | 描述                                                         | 工作量 |
| -----------: | ------------------------------------------------------------ | ------ |
| cve 信息获取 | 从四个常用 cve 参考网址中获取 cve 相关信息。                 | 1K     |
|     补丁获取 | 整合获取的 cve 信息，提取 commits、pr、issue，分析补丁内容。 | 1k     |

**AR：issue 评论**

|           SR | 描述                                                                          | 工作量 |
| -----------: | ----------------------------------------------------------------------------- | ------ |
| 评论内容拼接 | 将获取到的补丁信息，封装拼接成最终需要评论到（cve）issue 中的内容。           | 0.2k   |
| 补丁信息评论 | 封装 gitee 对 issue 的评论接口，将拼接好的补丁信息添加到（cve）issue 评论中。 | 0.3k   |

**AR：补丁下载**

|       SR | 描述                                 | 工作量 |
| -------: | ------------------------------------ | ------ |
| 补丁下载 | 根据获取到的补丁链接，进行下载保存。 | 0.3k   |

**AR：补丁验证**

|       SR | 描述                                                                                          | 工作量 |
| -------: | --------------------------------------------------------------------------------------------- | ------ |
| 补丁验证 | 根据下载的补丁文件，以及软件包的 gitee 地址，下载源代码，修改 spec 文件，进行软件包打包验证。 | 0.5k   |

### 3.10、接口清单

#### 3.10.1、查找补丁信息 find_patches_info()

> 说明：在各个 cve 参考网址爬取 cve 的补丁信息，先初步记录参考网址上列出的网址。

入参：

| 名称            | 类型 | 说明                                         |
| --------------- | ---- | -------------------------------------------- |
| cve_num         | str  | cve 编号                                     |
| rpm_name        | str  | rpm 包名称                                   |
| \*cve_plantform | str  | cve 查找参考网址，可使用属性值表示，无需传入 |

返回值：

| 名称         | 类型 | 说明         |
| ------------ | ---- | ------------ |
| \*patch_info | dict | 补丁相关信息 |

patch_info:

```json
{
    "plantform": "nvd_url"
    "commits": ["commit1","commit2"],
	"pr": ["pr1","pr2"],
	"issue": ["issue1","issue2"]
}
```

#### 3.10.2、查找补丁链接 find_patches_detail()

> 说明：对 find_patches_info 查询的信息做进一步处理，获取补丁链接。

入参：

| 名称        | 类型       | 说明                                      |
| ----------- | ---------- | ----------------------------------------- |
| patch_infos | list(dict) | find_patches_info()接口查出的补丁信息列表 |

patch_infos：

```json
[
{
    "plantform": "nvd_url"
    "commits": ["commit11","commit12"],
	"pr": ["pr11","pr12"],
	"issue": ["issue11","issue12"]
},
{
    "plantform": "buzila_url"
    "commits": ["commit21","commit22"],
	"pr": ["pr21","pr22"],
	"issue": ["issue21","issue22"]
}
]
```

返回值：

| 名称          | 类型       | 说明                 |
| ------------- | ---------- | -------------------- |
| patch_details | list(dict) | 补丁链接详细信息列表 |

patch_details：

```json
[
  {
    "plantform": "nvd_url",
    "details": {
      "issue1": {
        "url": "issue1_url",
        "status": "close",
        "prs": [
          {
            "url": "pr1_url",
            "status": "open",
            "commits": ["commit1", "commit2"]
          }
        ]
      }
    }
  },
  {
    "plantform": "buzila_url",
    "details": {
      "issue1": {
        "url": "",
        "status": "",
        "prs": [
          {
            "url": "",
            "status": "",
            "commits": ["commit1", "commit2"]
          }
        ]
      }
    }
  }
]
```

#### 3.10.3、评论 issue add_comment()

> 说明：根据 patch_details 获取的补丁详细信息，拼接 issue 评论内容，添加 issue 评论。

入参：

| 名称          | 类型       | 说明                                                    |
| ------------- | ---------- | ------------------------------------------------------- |
| issue_num     | str        | issue 编号                                              |
| patch_details | list(dict) | 补丁链接详细信息列表，结构见 find_patches_detail 返回值 |

返回值：

| 名称 | 类型 | 说明                                       |
| ---- | ---- | ------------------------------------------ |
| code | str  | 调用 gitee api 添加 issue 评论返回的状态码 |
| text | str  | 调用 gitee api 添加 issue 评论返回的信息   |

#### 3.10.4、下载保存 save_patch()

> 说明：根据 find_patches_detail 获取到的补丁信息，进行补丁文件下载。

入参：

| 名称          | 类型       | 说明                                                    |
| ------------- | ---------- | ------------------------------------------------------- |
| patch_details | list(dict) | 补丁链接详细信息列表，结构见 find_patches_detail 返回值 |
| cve_num       | str        | cve 编号                                                |
| \*save_path   | str        | 补丁文件保存路径，可不指定，有默认值。                  |

返回值：

> 无返回值，下载信息记录日志

#### 3.10.5、打包验证 packing_source()

> 说明：根据 save_patch 保存的补丁文件，以及软件包信息，从 gitee 拉取源代码，修改 spec，进行打包测试。

入参：

| 名称          | 类型 | 说明                                            |
| ------------- | ---- | ----------------------------------------------- |
| rpm_name      | str  | 补丁对应的软件包名称，用于从 gitee 中拉取源代码 |
| \*source_path | str  | 源码下载路径，可不指定，有默认值。              |
| \*save_path   | str  | 补丁文件保存路径，可不指定，有默认值。          |

返回值：

> 无返回值，编译过程记录文件，编译结果记录日志。

#### 3.10.6、补丁信息反馈 create_feedback_issue()

> 说明：反馈 cve 参考网址和补丁 url 信息，到指定仓库下提交 issue

入参：

| 名称           | 类型 | 说明                                      |
| -------------- | ---- | ----------------------------------------- |
| cve_num        | str  | cve 编号                                  |
| cve_platform   | str  | cve 参考网址                              |
| patch_url      | str  | 补丁 url 链接                             |
| issue_platform | str  | 提交 issue 的平台                         |
| \*owner        | str  | 提交 issue 所在的 owner，在配置文件中配置 |
| \*repo         | str  | 提交 issue 所在的 repo, 在配置文件中配置  |
