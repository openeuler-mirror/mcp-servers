import os

from conf import settings
from exception import ConfigNotFoundError
from logger import logger
from . import Api


class Atomgit(Api):
    host = "https://api.atomgit.com/api/v5/repos"

    def __init__(self):
        super(Atomgit, self).__init__()
        self.token = os.getenv("TRACK_GITCODE_TOKEN", settings.token(name="gitcode"))
        if not self.token:
            raise ConfigNotFoundError(
                "Please set the 'TRACK_GITCODE_TOKEN' environment variables of atomgit."
            )

    @property
    def _headers(self):
        headers = {}
        if self.token:
            headers["private-token"] = self.token
        return headers

    async def create_issue_comment(self, number, body):
        url = f"{self.host}/{self._owner}/{self._repo}/issues/{number}/comments"
        values = self._set_token()
        values["body"] = body
        logger.info(f"Add comment to issue url: {url}")
        return await self._post(url, values, headers=self._headers)
