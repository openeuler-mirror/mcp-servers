#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/
import os

from exception import ConfigNotFoundError
from conf import CONFIG, settings
from . import Api


class Gitlab(Api):
    host = "https://gitlab.com/api/v4/projects"

    def __init__(self) -> None:
        if not settings.token(name="gitlab") and not os.getenv("GITLAB_TOKEN", None):
            raise ConfigNotFoundError(
                "Please set the 'GITLAB_TOKEN' environment variable for gitlab."
            )
        super(Gitlab, self).__init__()

    @property
    def _headers(self):
        return {"PRIVATE-TOKEN": os.getenv("GITLAB_TOKEN", settings.token('gitlab'))}

    async def get_commit_comments(self, commit_sha):
        """
        Get the comments of a commit in a project.

        :param commit_sha: The commit hash or name of a repository branch or tag
        """
        url = f"{self.host}/{self._owner}%2F{self._repo}/repository/commits/{commit_sha}/comments"
        return await self._get(url, headers=self._headers)

    async def get_single_mr(self, merge_request_iid):
        """
        Shows information about a single merge request.

        :param merge_request_iid: The internal ID of the merge request.
        """
        url = f"{self.host}/{self._owner}%2F{self._repo}/merge_requests/{merge_request_iid}"
        return await self._get(url, headers=self._headers)

    async def get_mr_comments(self, merge_request_iid):
        """
        Gets a list of all notes for a single merge request.

        :param merge_request_iid: The internal ID of the merge request.
        """

        url = f"{self.host}/{self._owner}%2F{self._repo}/merge_requests/{merge_request_iid}/notes"
        return await self._get(url, headers=self._headers)

    async def get_mr_context_commits(self, merge_request_iid):
        """
        Get a list of merge request context commits.

        :param merge_request_iid: The internal ID of the merge request.
        """

        url = f"{self.host}/{self._owner}%2F{self._repo}/merge_requests/{merge_request_iid}/commits"

        return await self._get(url, headers=self._headers)

    async def issue_relevance_pull(self, issue_id):
        """
        Get all merge requests that close a particular issue when merged.

        :param issue_id:  The internal ID of a project issue
        """
        url = f"{self.host}/{self._owner}%2F{self._repo}/issues/{issue_id}/closed_by"
        return await self._get(url, headers=self._headers)

    async def create_issue(self, title, body):
        """
        Creates a new project issue.
        :param title: issue title
        :param body: issue body
        :return:
        """
        url = f"{self.host}/{self._owner}%2F{self._repo}/issues"
        params = {'title': title,
                  'description': body}
        return await self._post(url, headers=self._headers, values=params)
