#!/bin/bash
# shellcheck disable=SC2068
# shellcheck disable=SC2164
# shellcheck disable=SC2002
# shellcheck disable=SC2045
# shellcheck disable=SC2115
rpm_name=$1
rpm_branch=$2
patch_path=$3
source_path=$4
cve_num=$5
path_file_name=""
install_retry_count=0
# The rpm package that needs to be installed when compiling
requires_rpms=""
spec_file=""
# home_path=$(
#   cd ~
#   pwd -P
# )
# root_build_path=${home_path}/"rpmbuild"
root_build_path=$6
current_path=$(
  cd "$(dirname "$0")"
  pwd
)
. ${current_path}/common.sh
function check() {
  # Check input legitimacy
  if [[ -z ${rpm_name} ]] || [[ -z ${rpm_branch} ]]; then
    echo "[ERROR] rpm name or gitee branch not specified"
    exit 1
  fi
  # Check if the path exists
  if [[ ! -d ${patch_path} ]] || [[ ! -d ${source_path} ]]; then
    echo "[ERROR] The patch file directory: ${patch_path} or the source code download directory: ${source_path} does not exist is not exist"
    exit 1
  fi
}

function run() {
  patch_path="${patch_path%/}"
  if [[ "${patch_path}" == */"${cve_num}" ]]; then
    patch_dir="${patch_path}"
    patch_path="${patch_path%/${cve_num}}"
  else
    patch_dir="${patch_path}/${cve_num}"
  fi
  patch_files=$(ls "${patch_dir}")
  patch_ids=""
  new_patches=""
  for patch_file in ${patch_files[@]}; do
    patch_file=${patch_dir}/${patch_file}
    if [[ -d ${patch_file} ]]; then
      continue
    fi
    git_patch_ids=$(cat "${patch_file}" | git patch-id --stable)
    if [[ ! ${patch_ids} =~ ${git_patch_ids} ]]; then
      new_patches="${new_patches} ${patch_file}"
      patch_ids="${patch_ids} ${git_patch_ids}"
    else
      echo "[INFO] ${patch_file} duplicate content"
    fi
  done
  # Perform code download, modify spec file, package verification operation
  /bin/bash ${current_path}/packing.sh "${rpm_name}" "${rpm_branch}" "${patch_path}" "${source_path}" "${cve_num}" "${root_build_path}"
  add_patch_result=$?
  if [[ ${add_patch_result} -eq 0 ]]; then
    echo "[INFO] rpm: \"${rpm_name}\" of branch: \"${rpm_branch}\" apply patch \"${new_patches}\" successfully"
    exit 0
  else
    echo "[ERROR] rpm: \"${rpm_name}\" of branch: \"${rpm_branch}\" failed to apply patch \"${new_patches}\""
    exit 1
  fi
}

function main() {
  # Executive total entrance
  check
  install_rpm git git
  run
}

main
