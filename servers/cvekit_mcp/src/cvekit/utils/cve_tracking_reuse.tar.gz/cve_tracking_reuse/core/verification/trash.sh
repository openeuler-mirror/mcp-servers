#!/bin/bash
# shellcheck disable=SC2068
# shellcheck disable=SC2164
# shellcheck disable=SC2010
# shellcheck disable=SC2063
# shellcheck disable=SC2062
# shellcheck disable=SC2035
patch_path=$1
home_path=$(
  cd ~
  pwd -P
)
root_build_path=${home_path}/"rpmbuild"
rm $root_build_path/SOURCES/* -rf
rm $root_build_path/SPECS/* -rf
rm $root_build_path/BUILD/* -rf
rm $patch_path/* -r