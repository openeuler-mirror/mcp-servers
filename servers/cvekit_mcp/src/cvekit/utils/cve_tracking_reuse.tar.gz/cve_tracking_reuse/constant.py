#!/usr/bin/python3
# ******************************************************************************
# Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
# licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# ******************************************************************************/


class Constant:
    """
    Constant class
    """

    # gitlab host format
    GITLAB_HOST_REGEX = r"http[s]?://gitlab(?:[-\w.?])+"
    """
    Code hosting platform related
    """
    # github
    GITHUB = "github"
    # gitlab
    GITLAB = "gitlab"
    # Supported code hosting platforms
    CODE_PLATFORM = ["gitee", "github", "gitlab"]

    """
    Other
    """
    # The longest waiting time default
    MAX_DELAY = 180
    # The longest waiting time for url calls
    CALL_MAX_DELAY = 60
    # The longest waiting time for download
    MAX_DOWNLOAD_DELAY = 120
    # Maximum number of retries for failed URL calls
    MAX_RETRY = 3
