
import json
from typing import Optional, Callable, Union
from a2a.types import TaskState, TextPart

from camel.agents import MCPAgent
from camel.parsers.mcp_tool_call_parser import extract_tool_calls_from_text
from camel.messages import BaseMessage

class CallbackMCPAgent(MCPAgent):
    def __init__(self, *args, task_updater: Optional[Callable] = None,**kwargs):
        super().__init__(*args, **kwargs)
        self.final_agent_response = ""
        self.task_updater = task_updater

    async def astep(self, input_message: Union[BaseMessage, str], *args, **kwargs):
        if self.mcp_toolkit and not self.mcp_toolkit.is_connected:
            await self.connect()

        if self.function_calling_available:
            return await super().astep(input_message, *args, **kwargs)
        else:
            task = f"## Task:\n {input_message}"
            input_message = str(self._text_tools) + task
            response = await super(MCPAgent, self).astep(input_message, *args, **kwargs)
            raw_content = response.msgs[0].content if response.msgs else ""
            content = raw_content if isinstance(raw_content, str) else str(raw_content)

            tool_calls = extract_tool_calls_from_text(content)
            self.tool_call_history = []

            if not tool_calls:
                return response

            tools_results = []

            for tool_call in tool_calls:
                try:
                    server_idx = tool_call.get('server_idx')
                    tool_name = tool_call.get('tool_name')
                    tool_args = tool_call.get('tool_args', {})

                    if server_idx is None or tool_name is None:
                        continue

                    if (not isinstance(server_idx, int) or
                        server_idx < 0 or
                        server_idx >= len(self.mcp_toolkit.clients)):
                        continue

                    if self.task_updater: 
                        await self.task_updater.update_status(
                            state=TaskState.working,
                            message=self.task_updater.new_agent_message(
                                parts=[TextPart(text=f"tool_start, tool_name:{tool_name}, tool_args:{tool_args}")]
                            )
                        )
                    
                    self.tool_call_history.append({
                        "status": "running",
                        "tool_name": tool_name,
                        "tool_args": tool_args,
                        "message": f"正在调用工具:{tool_name}"
                    })

                    server = self.mcp_toolkit.clients[server_idx]
                    result = await server.call_tool(tool_name, tool_args)

                    result_text = None
                    if result.content and len(result.content) > 0:
                        result_text = result.content[0].text

                    if self.task_updater:
                        await self.task_updater.update_status(
                            state=TaskState.working,
                            message=self.task_updater.new_agent_message(
                                parts=[TextPart(text=f"tool_complete, tool_name:{tool_name}, execuation_result:{str(result_text)}")] 
                            )
                        )

                    self.tool_call_history.append({
                        "status": "completed",
                        "tool_name": tool_name,
                        "result": str(result),
                        "message": f"工具 {tool_name} 调用完成"
                    })

                    if result.content and len(result.content) > 0:
                        tools_results.append({tool_name: result.content[0].text})
                    else:
                        tools_results.append({tool_name: "No result content available"})

                except Exception as e:
                    if self.task_updater:
                        await self.task_updater.update_status(
                            state=TaskState.working,
                            message=self.task_updater.new_agent_message(
                                parts=[TextPart(text=f"tool_failed, {tool_name} encounters error: {str(e)}")]
                            )
                        )

                    self.tool_call_history.append({
                        "status": "failed",
                        "tool_name": tool_name,
                        "error": str(e),
                        "message": f"工具 {tool_name} 调用失败"
                    })
                    tools_results.append({"error": str(e)})

            results = json.dumps(tools_results)
            # print(tool_calls, results)

            final_prompt = f"Based on the following tool results:\n{results}\n\nPlease provide a final response."
            response = await self.astep(final_prompt)
            return response